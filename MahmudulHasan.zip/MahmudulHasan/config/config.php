<?php
define("DB_HOST", "localhost");
define("DB_USER", "bdjd28lictprojec");
define("DB_PASS", "pOq*~1AKysP8");
define("DB_NAME", "bdjd28li_oes");

?>