<?php
	$filepath = realpath(dirname(__FILE__));
	include_once ($filepath.'/../lib/Session.php');
	Session::init();
	include_once ($filepath.'/../lib/Database.php');
	include_once ($filepath.'/../helpers/Format.php');
	
	spl_autoload_register(function($class){
		include_once "classes/".$class.".php";
	});
	$db  = new Database();
	$fm  = new Format(); 
	$usr = new User();
	$exm = new Exam();
	$pro = new Process();
?>

<!doctype html>
<html>
<head>
<style>
.clockStyle {
    background-color: lightcyan;
    border: #999 1px inset;
    padding: 7px;
    color: #735f4a;
    font-family: "Arial Black", Gadget, sans-serif;
    font-size: 23px;
    font-weight: bold;
    letter-spacing: 3px;
    display: inline;
}
</style>
	<title>Online Exam System</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta http-equiv="Pragma" content="no-cache">
	<meta http-equiv="no-cache">
	<meta http-equiv="Expires" content="-1">
	<meta http-equiv="Cache-Control" content="no-cache">
	<link rel="stylesheet" href="css/main.css">
	<script type = "text/javascript" src="jvascrpt/jquery.js"></script>
   <script type = "text/javascript" src="jvascrpt/main.js"></script>
</head>
<body>


	<?php
		if(isset($_GET['action']) && $_GET['action'] == 'logout'){
			Session::destroy();
			header("Location:index.php");
			exit();
		}
	?>
	<style>
	
	.phpcoding{width:960px; margin: 0 auto;background:#0069ab;}
	</style>
	
<div class="phpcoding">
	<section class="headeroption">
	<h2 style="font-size:50px;">Online Exam system</h2>
	</section>
		<section class="maincontent">   
		<div class="menu">
		<ul>
		<?php
			$login = Session::get("login");
			if($login == true){
		?>
			<!--<li><a href="profile.php">Profile</a></li>-->
			<li><a href="exam.php">Exam</a></li>
			<li><a href="?action=logout">Logout</a></li>
			<?php } else { ?>
			<li><a href="index.php">Home</a></li>
			<div id="clockDisplay" class="clockStyle"></div>
<script>
function renderTime() {
	var currentTime = new Date();
	var diem = "AM";
	var h = currentTime.getHours();
	var m = currentTime.getMinutes();
    var s = currentTime.getSeconds();
	setTimeout('renderTime()',1000);
    if (h == 0) {
		h = 12;
	} else if (h > 12) { 
		h = h - 12;
		diem="PM";
	}
	if (h < 10) {
		h = "0" + h;
	}
	if (m < 10) {
		m = "0" + m;
	}
	if (s < 10) {
		s = "0" + s;
	}
    var myClock = document.getElementById('clockDisplay');
	myClock.textContent = h + ":" + m + ":" + s + " " + diem;
	myClock.innerText = h + ":" + m + ":" + s + " " + diem;
}
renderTime();
</script>
			<li><a href="register.php">About us</a></li>
			<?php } ?>
		</ul> 
		<?php
			$login = Session::get("login");
			if($login == true){
		?>
		<span style ="float:right;color:#fdfafb"; font-family : "Times New Roman", Georgia, Serif;>
		Welcome<strong><?php echo Session::get("name"); ?></strong> to this Exam....
		</span>
		<?php } ?>
		</div>
	</body>
</html>